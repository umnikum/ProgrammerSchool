#include <iostream>

#include "UI.h"

int main() {
	std::string line;
	UI ui;
	do{
		getline(std::cin, line);
	}while(ui.execute_command(line) != 0);
	return 0;
}
