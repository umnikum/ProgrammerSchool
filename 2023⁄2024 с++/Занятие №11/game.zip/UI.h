#ifndef UI_H_
#define UI_H_

#include <string>
#include "Engine.h"

class UI{
public:
	int execute_command(const std::string &command){
		if(command.compare("exit") == 0){
			return 0;
		}else if(command.compare("start") == 0){
			Engine engine{};
			engine.start();
			return 2;
		}
		return 1;
	}
private:

};



#endif /* UI_H_ */
